extends Label

func _on_score_end_score(value: int) -> void:
	text = str(value)
