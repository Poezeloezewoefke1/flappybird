extends Node2D

const SPEED := 50

func _physics_process(delta_time: float) -> void:
	self.position.x -= (delta_time * SPEED)
	
	if self.position.x < -13:
		self.position.x += 170
		self.position.y = randi_range(77,123)
		
