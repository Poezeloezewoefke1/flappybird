extends Node2D

func _ready() -> void:
	visible = false


func _on_bird_died() -> void:
	get_tree().paused= true
	visible = true
	


func _on_button_pressed() -> void:
	visible = false
	get_tree().reload_current_scene()
