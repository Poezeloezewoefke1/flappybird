extends Node2D

const GRAVITY := 250.0
const BOOST := 100.0
var speed := 0.0

@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D

func _physics_process(delta_time: float) -> void:
	if Input.is_action_just_pressed("ui_accept"):
		speed = -BOOST
		animated_sprite_2d.play("flap")
	speed += GRAVITY * delta_time
	self.position.y += speed * delta_time
	
	self.rotation = Vector2(50, speed *0.2).angle()
	

func _on_area_2d_area_entered(area: Area2D) -> void:
	get_tree().paused= true
