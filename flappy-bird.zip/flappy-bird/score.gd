extends Label

var score := 0

signal end_score(value: int)

func _on_pipes_scorepoint() -> void:
	score = score + 1
	text = str(score)

func _ready() -> void:
	visible = false

func _on_start_screen_started() -> void:
	visible = true


func _on_bird_died() -> void:
	visible = false
	end_score.emit(score)
	
