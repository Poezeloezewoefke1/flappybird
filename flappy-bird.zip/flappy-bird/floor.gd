extends Sprite2D

const SPEED := 50

func _physics_process(delta_time: float) -> void:
	self.position.x -= (delta_time * SPEED)
	
	if self.position.x < -12:
		self.position.x += 12
