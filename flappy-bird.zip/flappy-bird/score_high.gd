extends Label

const SAVE_PATH: String = "user://highscore.txt"

@onready var new: Sprite2D = $"../../NEW"


func _on_score_end_score(value: int) -> void:
	var high_score = 0
	
	if FileAccess.file_exists(SAVE_PATH):
		var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
		if file:
			high_score = file.get_as_text().to_int()

	if value > high_score:
		new.visible = true
		high_score = value
		var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
		if file:
			file.store_string(str(high_score))
	else:
		new.visible = false
		
	text = str(high_score)
	
