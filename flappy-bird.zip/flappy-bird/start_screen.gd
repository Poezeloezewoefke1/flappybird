extends Node2D

signal started

func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action("ui_accept"):
		get_tree().paused = false
		visible = false
		started.emit()
